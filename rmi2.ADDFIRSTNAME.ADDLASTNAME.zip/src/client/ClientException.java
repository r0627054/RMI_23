package client;

public class ClientException extends Exception  {

	public ClientException(String s) {
		super(s);
	}
}
